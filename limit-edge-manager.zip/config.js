// config.js - API Configuration
// This file contains the actual API keys for the team to use

const CONFIG = {
    // Google OAuth Client ID
    CLIENT_ID: '359299328467-17qtdae40gadksrj0spt5vj0r718t1o8.apps.googleusercontent.com',
    
    // Google API Key
    API_KEY: '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',
    
    // Gmail API Scopes
    SCOPES: 'https://www.googleapis.com/auth/gmail.readonly',
    
    // Discovery Document URL
    DISCOVERY_DOC: 'https://gmail.googleapis.com/$discovery/rest?version=v1',
    
    // App Configuration
    APP_NAME: 'Limit Edge Email Manager',
    APP_VERSION: '1.0.0',
    
    // Development/Production Environment
    ENVIRONMENT: 'production',
    
    // Debug Mode
    DEBUG: false
};

// Export configuration
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
} else {
    window.CONFIG = CONFIG;
}
